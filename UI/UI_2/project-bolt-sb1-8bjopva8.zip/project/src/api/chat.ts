import { ChatMessage, ChatAttachment } from '../types';

/**
 * @api {post} /api/chat/upload Upload file attachments
 * @apiName UploadAttachments
 * @apiGroup Chat
 * 
 * @apiParam {File[]} files Files to upload
 * 
 * @apiSuccess {Object[]} attachments Array of uploaded attachment objects
 * 
 * @apiSuccessExample {json} Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "attachments": [
 *         {
 *           "id": "att123",
 *           "fileName": "document.pdf",
 *           "fileUrl": "https://storage.example.com/files/document.pdf",
 *           "fileType": "application/pdf",
 *           "fileSize": 1024
 *         }
 *       ]
 *     }
 */
export async function uploadAttachments(files: File[]): Promise<ChatAttachment[]> {
  const formData = new FormData();
  files.forEach(file => formData.append('files', file));

  const response = await fetch('/api/chat/upload', {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    throw new Error('Failed to upload attachments');
  }

  return response.json();
}

/**
 * @api {post} /api/chat/messages Send a chat message
 * @apiName SendMessage
 * @apiGroup Chat
 * 
 * @apiParam {String} content Message content
 * @apiParam {String} receiverId Recipient's ID
 * @apiParam {String[]} [attachmentIds] Optional array of attachment IDs
 * 
 * @apiSuccess {Object} message Created message object
 * 
 * @apiSuccessExample {json} Success-Response:
 *     HTTP/1.1 201 Created
 *     {
 *       "id": "msg123",
 *       "content": "Here are the project files",
 *       "senderId": "user123",
 *       "receiverId": "support",
 *       "timestamp": "2025-03-20T10:30:00Z",
 *       "isRead": false,
 *       "attachments": [
 *         {
 *           "id": "att123",
 *           "fileName": "project.pdf",
 *           "fileUrl": "https://storage.example.com/files/project.pdf",
 *           "fileType": "application/pdf",
 *           "fileSize": 1024
 *         }
 *       ]
 *     }
 */
export async function sendMessage(
  content: string,
  receiverId: string,
  attachmentIds?: string[]
): Promise<ChatMessage> {
  const response = await fetch('/api/chat/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      content,
      receiverId,
      attachmentIds,
    }),
  });

  if (!response.ok) {
    throw new Error('Failed to send message');
  }

  return response.json();
}

/**
 * @api {get} /api/chat/messages Get chat messages
 * @apiName GetMessages
 * @apiGroup Chat
 * 
 * @apiParam {String} userId User's ID
 * @apiParam {Number} [limit=50] Maximum number of messages to retrieve
 * @apiParam {String} [before] Get messages before this timestamp
 * 
 * @apiSuccess {Object[]} messages Array of chat messages
 * 
 * @apiSuccessExample {json} Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "messages": [
 *         {
 *           "id": "msg123",
 *           "content": "Hello, I need help",
 *           "senderId": "user123",
 *           "receiverId": "support",
 *           "timestamp": "2025-03-20T10:30:00Z",
 *           "isRead": true,
 *           "attachments": []
 *         }
 *       ],
 *       "hasMore": true
 *     }
 */
export async function getMessages(
  userId: string,
  limit = 50,
  before?: string
): Promise<{ messages: ChatMessage[]; hasMore: boolean }> {
  const params = new URLSearchParams({
    userId,
    limit: limit.toString(),
    ...(before && { before }),
  });

  const response = await fetch(`/api/chat/messages?${params}`);

  if (!response.ok) {
    throw new Error('Failed to fetch messages');
  }

  return response.json();
}

/**
 * @api {patch} /api/chat/messages/:id/read Mark message as read
 * @apiName MarkMessageRead
 * @apiGroup Chat
 * 
 * @apiParam {String} id Message ID
 * 
 * @apiSuccess {Object} message Updated message object
 * 
 * @apiSuccessExample {json} Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "id": "msg123",
 *       "isRead": true
 *     }
 */
export async function markMessageAsRead(messageId: string): Promise<void> {
  const response = await fetch(`/api/chat/messages/${messageId}/read`, {
    method: 'PATCH',
  });

  if (!response.ok) {
    throw new Error('Failed to mark message as read');
  }
}