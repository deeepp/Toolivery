import { CartItem } from '../types';

/**
 * @api {post} /api/cart/add Add items to cart from chat
 * @apiName AddToCartFromChat
 * @apiGroup Cart
 * 
 * @apiSuccess {Object[]} items Array of items added to cart
 * 
 * @apiSuccessExample {json} Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "items": [
 *         {
 *           "prodName": "2x4 Wooden Stud",
 *           "prodQty": 10,
 *           "prodDim": "2 in x 4 in x 8 ft",
 *           "prodSeller": "Lowe's"
 *         }
 *       ]
 *     }
 */
export async function addToCartFromChat(): Promise<{
  items: Array<{
    prodName: string;
    prodQty: number;
    prodDim: string;
    prodSeller: string;
  }>;
}> {
  const response = await fetch('/api/cart/add', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error('Failed to add items to cart');
  }

  return response.json();
}